from io import *


def write_to_file(file_name, mode, data):
    f = open(file_name, mode)
    f.write(data)
    f.close()
